#!/usr/bin/env python
"""
https://github.com/zvtvz/zvt/blob/a83095217f120b78ca976c8231ae1707aeb8306b/src/zvt/recorders/em/em_api.py

"""
