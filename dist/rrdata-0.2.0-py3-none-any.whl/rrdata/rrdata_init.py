    """
    1. mkdir .rrsdk/setting
    2. check rrdatd -- rrdata(database)
    (trade_cal,swl_list,stock_list, stock_day_bfq, hfq_adj,
    swl_day_L1,2, )
    """
    
    