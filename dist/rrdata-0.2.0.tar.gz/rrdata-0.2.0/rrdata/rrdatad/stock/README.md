# use eastmoney data (hist and spot)
 see akshare/stock_feature/stock_hist_em.py

 if just caculate 250 days(52 weeks hist days),
 use qfq for default
 