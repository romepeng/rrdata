# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['rrdata',
 'rrdata.rrdatac',
 'rrdata.rrdatac.index',
 'rrdata.rrdatad',
 'rrdata.rrdatad.index',
 'rrdata.rrdatad.stock',
 'rrdata.utils']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'rrdata',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'romepeng',
    'author_email': 'romepeng@outlook.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
