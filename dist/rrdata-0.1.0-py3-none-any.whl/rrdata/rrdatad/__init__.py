from .index import (sw_index_spot,
                    sw_index_daily,
                    sw_index_daily_indicator,
                    sw_index_class,
                    sw_index_cons,
                    sw_index_class_all
                    )
