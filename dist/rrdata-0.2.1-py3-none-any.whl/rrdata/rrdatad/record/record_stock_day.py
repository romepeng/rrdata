from rrdata.rrdatad.stock.save_stock_day import save_stock_day_bfq_to_pgsql, save_stock_day_hfq_to_pgsql

save_stock_day_bfq_to_pgsql()
save_stock_day_hfq_to_pgsql()


