# todo
1. fillna by trade_date ( list_date / fillna metod);
   save adj_factor --all code by trade_date
2. make stock day bfq-fillna-adjfactor -- first get adj_factor (trade_date--all ts_code);
3. MA_OH_VOLChg_RT_RS--PEROID(5,10,20,60,120,250);

