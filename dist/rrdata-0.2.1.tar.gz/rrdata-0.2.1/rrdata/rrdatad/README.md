1. fetch data from finance webpage or other opensource api.
2. date to unit code types;
3. record or save datas to sql (postgresql12).

includes:
1. stock_calendar;
2.stock_basic _info;
3.stock_list;
4. stock_daily(Nfq, Qfq, Hfq);
5.swl_index;(swl_class, cons, spot --L1,L2)
6.stock_finance ....



#logging.basicConfig(level=logging.INFO, format=' %(asctime)s- %(levelname)s-%(message)s')