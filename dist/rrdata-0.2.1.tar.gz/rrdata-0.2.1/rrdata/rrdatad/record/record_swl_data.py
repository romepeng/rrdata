from rrdata.rrdatad.index.save_index_sw_pgsql import (save_index_sw_class_pgsql,
                        save_all_stock_belong_swl)                   

save_index_sw_class_pgsql()
save_all_stock_belong_swl()


